package com.example.demo;

import java.util.concurrent.ConcurrentHashMap;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;


public class WebsocketEchoHandler extends TextWebSocketHandler {
//concurrent hash map
	ConcurrentHashMap<String,WebSocketSession> Jugadores = new ConcurrentHashMap<>();	
	private ObjectMapper mapper = new ObjectMapper();

	
	
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
		System.out.println("Position received: " + message.getPayload());
		JsonNode informacion = mapper.readTree(message.getPayload());
		sendOtherParticipants(session, informacion);
		
	}

	private void sendOtherParticipants(WebSocketSession session, JsonNode informacion) throws IOException {


		ObjectNode informacionActualizada = mapper.createObjectNode();
//en un futuro se enviará el id
		informacionActualizada.put("posicionX", informacion.get("posicionX").asInt()); //pone en el campo nombre del json Informacion al campo nombre del Json informacionAct
		informacionActualizada.put("posicionY", informacion.get("posicionY").asInt());
		System.out.println("hola");
		for(WebSocketSession player : Jugadores.values()) {
			if(!player.getId().equals(session.getId())) {
				player.sendMessage(new TextMessage(informacionActualizada.toString()));
				System.out.println("Position sent to: " + player.getId());
			}
			}
		}
	
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception { //si eres el primer jugador, te envia, tu posicion, la posicion de las bombas y tu id
		Jugadores.put(session.getId(), session);
		System.out.println("Jugador: " + session.getId() + " conectado");
		session.sendMessage(new TextMessage("hola, estas conectado"));
	}
	/*
	protected void EnviarDatosCambiadosPorElJugador(WebSocketSession session, Posicion posicion) throws Exception {
		System.out.println("Message received");
		String idSender = session.getId();
		/*
		for(int i =0; i<Jugadores.mappingCount(); i++) {
			if (Jugadores.!=idSender) {
				Jugadores[i].sendMessage(new TextMessage(posicion.toString()));
			}
		}
		Jugadores.forEach((key,value)->{ if(key!=idSender) {try {
			value.sendMessage(new TextMessage(posicion.toString()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}});
		*/
		
		
	//}
	
}


//	}
//Meterlos concurrent hashmap (NADA MAS CONECTARSE) 1 por jugador
// MANDAR MENAJES (emisor, mensaje)
	//metodo que reciba objeto WebsocketSession session, Info info 
	// a todos los usuarios que no sean yo, mandar este mensaje


