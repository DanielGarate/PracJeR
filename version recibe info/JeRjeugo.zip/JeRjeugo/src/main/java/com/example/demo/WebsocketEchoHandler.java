package com.example.demo;

import java.util.concurrent.ConcurrentHashMap;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;


public class WebsocketEchoHandler extends TextWebSocketHandler {
//concurrent hash map
	InformacionParaElServidor info = new InformacionParaElServidor(0,0);
	ConcurrentHashMap<String,WebSocketSession> Jugadores = new ConcurrentHashMap<>();	
	
	
	
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
		System.out.println("Position received: " + message.getPayload());
		sendOtherParticipants(session, message.getPayload());
	}

	private void sendOtherParticipants(WebSocketSession session, String payload) throws IOException {
		for(WebSocketSession player : Jugadores.values()) {
			if(!player.getId().equals(session.getId())) {
				player.sendMessage(new TextMessage(payload));
				System.out.println("Position sent to: " + player.getId());
			}
			}
		}
	
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		Jugadores.put(session.getId(), session);
		System.out.println("Jugador: " + session.getId() + " conectado");
		session.sendMessage(new TextMessage("hola, estas conectado"));
	}
	/*
	protected void EnviarDatosCambiadosPorElJugador(WebSocketSession session, Posicion posicion) throws Exception {
		System.out.println("Message received");
		String idSender = session.getId();
		/*
		for(int i =0; i<Jugadores.mappingCount(); i++) {
			if (Jugadores.!=idSender) {
				Jugadores[i].sendMessage(new TextMessage(posicion.toString()));
			}
		}
		Jugadores.forEach((key,value)->{ if(key!=idSender) {try {
			value.sendMessage(new TextMessage(posicion.toString()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}});
		*/
		
		
	//}
	
}


//	}
//Meterlos concurrent hashmap (NADA MAS CONECTARSE) 1 por jugador
// MANDAR MENAJES (emisor, mensaje)
	//metodo que reciba objeto WebsocketSession session, Info info 
	// a todos los usuarios que no sean yo, mandar este mensaje


