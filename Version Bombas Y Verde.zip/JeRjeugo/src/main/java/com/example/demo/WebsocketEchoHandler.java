package com.example.demo;

import java.util.concurrent.ConcurrentHashMap;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;


public class WebsocketEchoHandler extends TextWebSocketHandler {
//concurrent hash map
	ConcurrentHashMap<String,WebSocketSession> Jugadores = new ConcurrentHashMap<>();	
	private ObjectMapper mapper = new ObjectMapper();
	int contadorJugadoresConectados=0;
	
	
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
		System.out.println("Position received: " + message.getPayload());
		JsonNode informacion = mapper.readTree(message.getPayload());
		
		//si es el mensaje de conectado
		if (informacion.get("EstaConectado")!=null && informacion.get("EmpezarPartida") == null) { //esto funciona
			contadorJugadoresConectados+=1;
			if (contadorJugadoresConectados>1) {
			sendAllParticipants(session,informacion);
			}
		}
		//resto de mensajes
		else if (informacion.get("EstaConectado")==null && informacion.get("EmpezarPartida") == null) {
			sendOtherParticipants(session, informacion);
		}
	}
	
	
	private void sendAllParticipants(WebSocketSession session, JsonNode informacion) throws IOException {
		ObjectNode informacionActualizada = mapper.createObjectNode();
			informacionActualizada.put("EmpezarPartida", true);
		
		System.out.println("hola, lo mando a ambos");
		for(WebSocketSession player : Jugadores.values()) {
				player.sendMessage(new TextMessage(informacionActualizada.toString()));
				System.out.println("Position sent to: " + player.getId());
		}
	}

	private void sendOtherParticipants(WebSocketSession session, JsonNode informacion) throws IOException {


		ObjectNode informacionActualizada = mapper.createObjectNode();
		if (informacion.get("posicionX")!=null) {
			informacionActualizada.put("posicionX", informacion.get("posicionX").asInt()); //pone en el campo nombre del json Informacion al campo nombre del Json informacionAct
			informacionActualizada.put("posicionY", informacion.get("posicionY").asInt());
		}
		//SI EL SERVIDOR RECIBE UN JSON CON LA INFORMACIION DE LAS  BOMBAS, LO COPIA EN OTRO JSON Y LO ENVIA AL OTRO JUGADOR
		if (informacion.get("posicionBombasX")!=null) {
			informacionActualizada.put("posicionBombasX", informacion.get("posicionBombasX").asInt()); //pone en el campo nombre del json Informacion al campo nombre del Json informacionAct
			informacionActualizada.put("posicionBombasY", informacion.get("posicionBombasY").asInt());
		}
		
		System.out.println("hola, lo mando al contrario");
		for(WebSocketSession player : Jugadores.values()) {
			if(!player.getId().equals(session.getId())) {
				player.sendMessage(new TextMessage(informacionActualizada.toString()));
				System.out.println("Position sent to: " + player.getId());
			}
			}
		}
	
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception { //si eres el primer jugador, te envia, tu posicion, la posicion de las bombas y tu id
		

		Jugadores.put(session.getId(), session);
		
		//
		ObjectNode informacionSpawn = mapper.createObjectNode();
		//
		if (Jugadores.mappingCount()>1) {
			informacionSpawn.put("Spawn", 1);
		}else {
			informacionSpawn.put("Spawn", 0);
		}
		System.out.println("Jugador: " + session.getId() + " conectado");
		session.sendMessage(new TextMessage(informacionSpawn.toString()));
	}
	}


