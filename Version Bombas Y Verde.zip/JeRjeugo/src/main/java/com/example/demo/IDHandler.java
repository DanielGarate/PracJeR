package com.example.demo;

public class IDHandler {

	private long id;
	private String user;
	
	public IDHandler() {
	}

	public long getId() {
		return id;
	}



	@Override
	public String toString() {
		return user + ": " + "/" +"\n";
	}

}
