$(document).ready(function(){
    console.log("El DOM está cargado")
    // Acciones sobre el documento
    });
    