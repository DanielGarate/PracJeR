package com.example.demo;
import java.util.*;

public class InformacionParaElServidor {
	int posicionX;
	int posicionY;
	int[] posxy = new int[2];
	public InformacionParaElServidor(int posX, int posY) {
		posxy[0]=posX;
		posxy[1]=posY;
	}
	public int[] GetInfo() {
		return posxy;
	}
	public void SetInfo(int x, int y) {
		posxy[0]=x;
		posxy[1]=y;
	}
}
